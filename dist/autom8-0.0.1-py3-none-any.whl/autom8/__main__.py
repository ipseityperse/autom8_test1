from . import *

dialog = Dialog()