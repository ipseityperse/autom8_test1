from . import Dialog
dialog = Dialog()